# Átállási Terv a Moduláris, Factory-Pattern-alapú Scraper Architektúrára

*Dátum: 2025-06-30*

---

## 1. Célkitűzés és Koncepció
Ez a dokumentum lépésről-lépésre leírja, hogyan álljunk át a jelenleg **Rockwool-fókuszú** scraper megoldásról a **moduláris, gyártó-független, Factory Pattern-alapú** architektúrára. A terv szinkronban van a meglévő fejlesztési back­log­gal és a következő hónapokra ütemezett feladatokkal.

[image:1]

## 2. Kiindulási Állapot
- **✔ PRODUCTION COMPLETE**: Rockwool termék- és árlista-scraper + DB integráció.
- **✔ INFRASTRUCTURE READY**: BrightData MCP rendszer, Celery automatizálás.
- **🔄 IN DEVELOPMENT**: Client-Specific Architecture váz, RAG Pipeline alapjai.
- **🔄 PLANNED**: Leier & Baumit scraperek, AI agent modulok, ajánlatkészítő, stb.

## 3. Célállapot
1. Egységes `clients/<gyártó>/` könyvtárstruktúra minden gyártóra.
2. `factory/client_factory.py` képes dinamikusan példányosítani bármely regisztrált scrapert **kódmódosítás nélkül**.
3. Meglévő Rockwool logika migrálva az új struktúrába _változatlan működéssel_.
4. Leier és Baumit scraperek hozzáadva, de csak *INFRASTRUCTURE READY* szinten a kezdeti migráció végére.
5. CI/CD pipeline minden kliens-modulra és regressziós tesztre.

## 4. Átállási Stratégia
### 4.1 Mig­rációs Elvek
| # | Elv | Jelentés |
|---|-----|----------|
| 1 | **Inkrementális migráció** | Funkciók váltása feature-flaggel, visszagörgethetően |
| 2 | **Open/Closed betartása** | Új gyártó = új modul, meglévő core változatlan |
| 3 | **Két-körös verifikáció** | AI unit-teszt + emberi E2E validálás |
| 4 | **Zero downtime** | Production környezetben folyamatos adatfrissítés |

### 4.2 Fő Fázisok és Kapcsolódásuk a Backloghoz
| Hét | Fázis | Backlog elem | Kimenet | Állapot címke |
|----|-------|--------------|---------|---------------|
| 1–2 | **Alap-architektúra** | Client-Specific Architecture | Mappa-struktúra, absztrakt osztályok | ✅ INFRASTRUCTURE READY |
| 2 | **Rockwool migráció** | Rockwool code extract & refactor | Új scraper regisztrálva, regressziós teszt | 🔍 AWAITING VERIFICATION |
| 3 | **Factory Pattern** | Factory implementation | `ClientFactory.create_scraper()` működik | ✅ INFRASTRUCTURE READY |
| 3–4 | **Leier prototípus** | Leier scraper implementáció | PDF+HTML parser váz, unit tests | 🔄 IN DEVELOPMENT |
| 4 | **Celery automata teszt** | Celery Automation Testing | Időzített Rockwool scraping | 🔍 AWAITING VERIFICATION |
| 5 | **Baumit prototípus** | Baumit scraper implementáció | JS-render + színmátrix logika váz | 🔄 IN DEVELOPMENT |
| 6 | **RAG Pipeline bővítés** | RAG Pipeline Foundation | 46+ termék vektor DB | 🔄 IN DEVELOPMENT |
| 7 | **E2E verifikáció** | BrightData MCP prod test + új scraperek | Teljes workflow emberi tesztje | 🔍 AWAITING VERIFICATION |
| 8 | **CI/CD & Monitoring** | Finalizálás & Deployment | GitHub Actions, metrics | 🔄 PLANNED |

## 5. Részletes Lépéssor
### 5.1 Fázis 1 – Architektúra Kibontása
1. Létrehozni a `clients/`, `shared/`, `factory/` gyökereket.
2. Közös absztrakt `BaseScraper`, `BaseParser`, `BaseClient` osztályok.
3. Központi logging, storage, MCP wrapper shared modulok.

### 5.2 Fázis 2 – Rockwool Kód Migrálása
```bash
mv rockwool_scraper_final.py clients/rockwool/scrapers/termekadatlapok.py
# Brochure és árlista scraper is költözik
```
- Konfiguráció kinyerése `clients/rockwool/config/` alá.
- Debug HTML-ek teszt fixture-ként.
- Unit- és integrációs tesztek frissítése.

### 5.3 Fázis 3 – Factory Pattern Bevezetése
```python
class ClientFactory:
    _scrapers = {}
    @classmethod
    def register_scraper(cls, client, s_type, klass):
        cls._scrapers[f"{client}_{s_type}"] = klass
```
- Rockwool regisztráció.
- Smoke-teszt: `ClientFactory.create_scraper("rockwool","termekadatlapok")`.

### 5.4 Fázis 4 – Leier & Baumit Prototípusok
- **Leier**: PDF lista letöltés, PyMuPDF parser keret.
- **Baumit**: Playwright session, színcsoport kalkulátor stub.
- Mindkettő **✅ INFRASTRUCTURE READY** címkével zár.

### 5.5 Fázis 5 – Automatizálás & RAG Integráció
- Celery Beat jobok új Factory-hívásokkal.
- Chroma vektor DB initializálás → RAG pipeline bekötése.

### 5.6 Fázis 6 – Teljes E2E Validáció
- BrightData MCP → Leier & Baumit próba.
- QA checklist (error rate < 15%, block rate < 5%).
- Documentation frissítés mandatory evidence formátumban.

## 6. Verifikációs Kapuk
| Kapu | Kritérium | Bizonyíték |
|------|-----------|-----------|
| **Checkpoint 1** | Rockwool scraper új struktúrában lefut | Unit log + 34 PDF DL ✔ |
| **Checkpoint 2** | Factory smoke test | `/api/clients/rockwool/...` 200 OK ✔ |
| **Checkpoint 3** | Leier prototípus PDF parse sample | Parsed 3 rekord minta log |
| **Checkpoint 4** | Baumit JS render sample | 1 termék + színár demo log |
| **Final Gate** | E2E human verifikáció | QA jegyzőkönyv, screenshotok |

## 7. Kockázatok és Enyhítésük
| Kockázat | Hatás | Mitigáció |
|----------|-------|-----------|
| Regressziós hiba Rockwool nál | Adatvesztés | Parallel futtatás + feature-flag |
| BrightData kvóta túllépése | Költségnövekedés | Rate-limit + API ONLY stratégia |
| Playwright flakiness Baumitnál | Időcsúszás | Retry + headless ‹–› headed switch |

## 8. Függőségek és Ütemezés
- **Emberi QA** elérhetőség a Checkpointoknál.
- **DevOps**: CI/CD pipeline kapacitás hét 8-ra.
- **BrightData**: Prod token jóváhagyás hét 2-ig.

## 9. Dokumentáció és Kommunikáció
- Minden fázis végén kötelező **MANDATORY DELIVERABLE FORMAT** szerint státusz update a `FEJLESZTESI_BACKLOG.mdc`-ben.
- Heti demo a stakeholdereknek (péntek 14:00).

## 10. Összegzés
Az átállás **8 hetes, hat fázisos** terv szerint halad, amely **nulla leállást** és **konfiguráció-vezérelt bővíthetőséget** biztosít. A Factory Pattern lehetővé teszi, hogy a Rockwool mellett a Leier és Baumit scraperek is gyorsan bevezethetők legyenek, miközben hosszú távon minimalizáljuk a regressziós hibák és karbantartási költségek kockázatát.
